package com.example.drivinglessons.fragments;

import androidx.fragment.app.Fragment;

public class InputStudentFragment extends Fragment
{

}
